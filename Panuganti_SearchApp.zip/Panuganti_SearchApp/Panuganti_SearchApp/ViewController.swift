//
//  ViewController.swift
//  Panuganti_SearchApp
//
//  Created by Sirisha Panuganti on 10/30/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    var topicsArr = [
        ["VW","mercedes","mazda","bmw","audi"],
        ["dog","cat","rabbit","squirrel","horse"],
        ["sunflower","rose","tulips","plumeria","marigold"]
    ]
    
    var cars_array = ["Volkswagen, or VW for short, is a car company from Germany. The word volkswagen means People's car in German. Its headquarters are in Wolfsburg, Lower Saxony.",
                      "Mercedes-Benz  is a brand of cars, trucks, buses and coaches from the Daimler AG company of Germany. Mercedes-Benz is the world's oldest car maker and the cars they make are expensive.",
                      "Mazda Motor Corporation, also known as simply Mazda, is a Japanese multinational automotive manufacturer headquartered in Fuchū, Hiroshima, Japan.",
                      "Bayerische Motoren Werke AG, abbreviated as BMW, is a German multinational manufacturer of luxury vehicles and motorcycles headquartered in Munich, Bavaria, Germany.",
                      "Audi AG is a German automotive manufacturer of luxury vehicles headquartered in Ingolstadt, Bavaria, Germany. A subsidiary of the Volkswagen Group, Audi produces vehicles in nine production facilities worldwide."
    ]
    var pets_array = ["Dogs are mammals, usually kept as pets or for work on farms or police. Some dogs are trained to be rescue dogs, and join teams such as mountain rescue.",
                      "Cats, also called domestic cats (Felis catus), are small, carnivorous mammals, of the family Felidae. A cat is sometimes called a kitty. A young cat is called a kitten.",
                      "Rabbits are mammals of the order Lagomorpha. There are about fifty different species of rabbits and hares. The order Lagomorpha is made of rabbits, pikas and hares.",
                      "Squirrels are a large family of small to medium rodents.The most common European squirrels are red or brown in color, while common American squirrels are grey or black.",
                      "The horse is a domesticated, one-toed, hoofed mammal.Horses are adapted to run, allowing them to quickly escape predators, and possess an excellent sense of balance and a strong fight-or-flight response."
                      
    ]
    var flowers_array = ["The sunflower (Helianthus annuus) is a living annual plant in the family Asteraceae, with a large flower head (capitulum).Sunflower whole seed (fruit) are sold as a snack food, after roasting in ovens.",
                         "A rose is either a woody perennial flowering plant of the genus Rosa  in the family Rosaceae. Roses are best known as ornamental plants grown for their flowers in the garden and sometimes indoors. ",
                         "Tulip sylvestris is a vigorous, scented, wild tulip. It has bright, buttercup-yellow flowers with a green rib running outside and pointed petals.",
                         "Plumeria (common name Frangipani) is a small genus of 7-8 species that grow in tropical and subtropical Americas.Plumeria is related to the Oleander, Nerium Oleander, and both possess poisonous, milky sap.",
                         "Tagetes is a genus of flowers commonly called marigold. Tagetes has 56 species [2] of plants in the sunflower family (Asteraceae or Compositae). The genus is native to North and South America."
                         
    ]
    var cars_keywords = ["car", "cars", "transport","vehicle","transportation","Automobiles","ride","motorcars","commute","travel"]
    var pets_keywords = ["animals","animal","domestic animals","household animals","animal companions","creatures","pet","pets"]
    var flowers_keywords = ["flower","flowers","flora","petals","blossoms","sunflower", "rose","Tulip","plumeria","marigold"]
    
    var topic = 3
    var imageNum = 0
    
    @IBOutlet weak var searchTextField: UITextField!
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var prevButtonOL: UIButton!
    
    @IBOutlet weak var nextButtonOL: UIButton!
    
    @IBOutlet weak var resetButton: UIButton!
    
    
    @IBOutlet weak var searchButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resultImage.image = UIImage(named : "welcome")
        topicInfoText.text = ""
        prevButtonOL.isHidden = true
        nextButtonOL.isHidden = true
        resetButton.isHidden = true
        //searchButton.isEnabled = false
        
    }
    @IBAction func searchFieldAction(_ sender: Any) {
        if(searchTextField.text == ""){
            searchButton.isEnabled = false
        }else{
            searchButton.isEnabled = true
        }
    }
    
    @IBAction func showPrevImagesBtn(_ sender: Any) {
            imageNum -= 1
        print(imageNum)
        if(imageNum >= 0 && imageNum < 5){
            UpdateDetails(topic, imageNum)
        }else{
            prevButtonOL.isEnabled = false
        }
    }
    
    
    
    @IBAction func ResetBtn(_ sender: Any) {
        prevButtonOL.isHidden = true
        nextButtonOL.isHidden = true
        resetButton.isHidden = true
        resultImage.image = UIImage(named: "welcome")
        topicInfoText.text = ""
        imageNum = 0
        topic = 3
        searchTextField.text! = ""
    }
    
    
    
    @IBAction func ShowNexImagesBtn(_ sender: Any) {
            imageNum += 1
        print(imageNum)
        if(imageNum >= 0 && imageNum < 5){
            UpdateDetails(topic, imageNum)
        }else{
            nextButtonOL.isEnabled = false
        }
    }
    
    @IBAction func serachButtonAction(_ sender: Any) {
        
        prevButtonOL.isHidden = false
        nextButtonOL.isHidden = false
        resetButton.isHidden = false

        nextButtonOL.isEnabled = true
        prevButtonOL.isEnabled = false
        
         imageNum = 0
        var searchKey = searchTextField.text!
        
        if(cars_keywords.contains(searchKey)){
            topic = 0
        }else if(pets_keywords.contains(searchKey)){
            topic = 1
        }
        else if(flowers_keywords.contains(searchKey)){
            topic = 2
        }else{
            topic = 3
        }
        
        switch topic{
        case 0: resultImage.image = UIImage(named : topicsArr[0][0])
            topicInfoText.text = cars_array[0]
        case 1: resultImage.image = UIImage(named : topicsArr[1][0])
            topicInfoText.text = pets_array[0]
        case 2:resultImage.image = UIImage(named : topicsArr[2][0])
            topicInfoText.text = flowers_array[0]
        default: resultImage.image = UIImage(named : "notFound")
            prevButtonOL.isHidden = true
            nextButtonOL.isHidden = true
            resetButton.isHidden = true
            topicInfoText.text = ""
            
            
            
        }
        
        
    }
    
    func UpdateDetails(_ topic: Int, _ indx:Int)
    {
        
        nextButtonOL.isEnabled = true
        prevButtonOL.isEnabled = true
        
        resultImage.image = UIImage(named: topicsArr[topic][indx])

        
        switch topic{
        case 0: topicInfoText.text = cars_array[indx]
        case 1: topicInfoText.text = pets_array[indx]
        case 2: topicInfoText.text = flowers_array[indx]
        default: topicInfoText.text = ""
            
            
        }
        
    }
}
